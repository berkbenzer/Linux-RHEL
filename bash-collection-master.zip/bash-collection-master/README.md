# bash-collection
With this project I release what I developed with bash script.
Mostly I return data from the servers like which vservers allowed to root login, priviledge users and inventory check.
